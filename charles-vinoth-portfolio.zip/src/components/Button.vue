<script setup>
const props = defineProps({
  label: {
    type: String,
    default: "label",
  },

  color: {
    type: String,
    default: "PRIMARY",
  },
});
</script>

<template>
  <button
    class="inline-flex items-center px-6 py-3 shadow-sm capitalize tracking-wider font-medium text-white rounded"
    :class="[
      props.color === 'SECONDARY'
        ? 'bg-cyan-500 dark:bg-cyan-400 hover:bg-cyan-600 dark:hover:bg-cyan-500'
        : 'bg-violet-500 dark:bg-violet-400 hover:bg-violet-600 dark:hover:bg-violet-500',
    ]"
  >
    {{ props.label }}

    <div class="h-6 w-6 text-white ml-3">
      <slot></slot>
    </div>
  </button>
</template>

<style scoped></style>
