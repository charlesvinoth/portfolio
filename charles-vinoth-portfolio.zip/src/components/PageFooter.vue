<script setup></script>

<template>
  <div class="px-6 xl:px-8 text-center">
    <div class="py-8 border-t border-gray-200 dark:border-gray-800">
      <div class="text-sm mb-1">
        Designed & Built with Vue.js by Charles Vinoth
      </div>
      <div class="text-xs text-gray-500 dark:text-gray-500">
        © Copyright 2022
      </div>
    </div>
  </div>
</template>

<style></style>
