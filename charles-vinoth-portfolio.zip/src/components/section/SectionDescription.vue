<script setup></script>

<template>
  <p class="text-gray-500 dark:text-gray-400 mb-10"><slot></slot></p>
</template>

<style scoped></style>
