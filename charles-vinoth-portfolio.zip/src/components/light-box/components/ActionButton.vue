<script setup></script>

<template>
  <div
    class="h-12 w-12 flex items-center justify-center cursor-pointer hover:bg-[#3d3d3d] text-gray-50"
  >
    <slot></slot>
  </div>
</template>

<style scoped></style>
