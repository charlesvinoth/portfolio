<script setup></script>

<template>
  <h1 class="font-bold capitalize mb-6 text-3xl md:text-5xl xl:text-6xl">
    Front-End Developer
  </h1>
</template>

<style scoped></style>
