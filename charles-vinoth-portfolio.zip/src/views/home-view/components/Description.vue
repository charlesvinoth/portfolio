<script setup></script>

<template>
  <p class="text-gray-500 dark:text-gray-400 mb-14 w-full xl:w-4/5">
    Front-end developer with more than 4 years of experience designing and
    developing responsive web and mobile applications. Proficient in HTML, CSS,
    and JavaScript frameworks with a thorough understanding of UI and UX.
    Notable accomplishments include an 80% increase in the sales of an existing
    product through improved design and code.
  </p>
</template>

<style scoped></style>
