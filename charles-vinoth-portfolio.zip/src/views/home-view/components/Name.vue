<script setup></script>

<template>
  <h1 class="flex items-center justify-center xl:justify-start mb-6">
    <div class="w-12 h-[2px] mr-4 bg-cyan-500 dark:bg-cyan-300"></div>
    <div
      class="text-lg font-semibold capitalize text-cyan-500 dark:text-cyan-300"
    >
      Hi, I am Charles Vinoth.
    </div>
  </h1>
</template>

<style scoped></style>
