<script setup>
const props = defineProps({
  technologies: {
    type: Array,
    default: () => [],
  },
});
</script>

<template>
  <div class="flex flex-wrap items-center gap-2">
    <div
      v-for="technology in props.technologies"
      :key="technology"
      class="px-6 py-2 rounded bg-cyan-600/10 text-cyan-600 dark:bg-cyan-400/10 dark:text-cyan-300 font-medium"
    >
      {{ technology }}
    </div>
  </div>
</template>

<style scoped></style>
