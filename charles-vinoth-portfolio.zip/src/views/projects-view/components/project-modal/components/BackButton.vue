<script setup>
import { BackIcon } from "@/components/Icons";
</script>

<template>
  <div
    class="inline-flex items-center gap-2 tracking-wider text-gray-500 dark:text-gray-400 hover:text-cyan-500 dark:hover:text-cyan-400 cursor-pointer py-2 pl-2 pr-4 bg-gray-100 dark:bg-gray-800 rounded"
  >
    <BackIcon class="h-5 w-5" />

    <div class="font-medium capitalize">back</div>
  </div>
</template>

<style scoped></style>
